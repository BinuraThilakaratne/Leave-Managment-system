﻿<script>
    document.addEventListener("DOMContentLoaded", function () {
    const exportBtn = document.getElementById("exportExcelBtn");
    if (exportBtn) {
        exportBtn.addEventListener("click", function () {
            const search = document.getElementById("searchInput").value;
            const status = document.getElementById("statusFilter").value;
            const url = `/Leave/ExportToExcel?search=${encodeURIComponent(search)}&status=${encodeURIComponent(status)}`;
            window.location.href = url;
        });
    }
});
</script>