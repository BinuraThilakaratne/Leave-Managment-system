﻿let allLeaves = [];

document.addEventListener("DOMContentLoaded", () => {
    loadLeaves();

    document.getElementById("searchInput").addEventListener("keyup", filterLeaves);
    document.getElementById("statusFilter").addEventListener("change", filterLeaves);
    document.getElementById("exportBtn").addEventListener("click", exportCSV);
    document.getElementById("saveEditBtn").addEventListener("click", saveEditLeave);

    // Event delegation for dynamic buttons
    document.getElementById("leaveTableBody").addEventListener("click", function (e) {
        const row = e.target.closest("tr");
        if (!row) return;
        const leaveId = row.dataset.id;
        if (e.target.classList.contains("edit-btn")) openEditModal(leaveId);
        if (e.target.classList.contains("delete-btn")) deleteLeave(leaveId);
        if (e.target.classList.contains("approve-btn")) updateStatus(leaveId, "Approved");
        if (e.target.classList.contains("reject-btn")) updateStatus(leaveId, "Rejected");
    });
});

async function loadLeaves() {
    try {
        const response = await fetch("https://localhost:7272/api/Leave/GetAllLeaves");
        allLeaves = await response.json();
        renderTable(allLeaves);
        updateDashboard(allLeaves);
    } catch (err) {
        console.error(err);
    }
}

function renderTable(data) {
    const table = document.getElementById("leaveTableBody");
    table.innerHTML = "";

    data.forEach(leave => {
        const start = new Date(leave.startDate);
        const end = new Date(leave.endDate);
        const submitted = new Date(leave.submittedOn);

        const totalDays = Math.round((end - start) / (1000 * 60 * 60 * 24)) + 1;

        const row = document.createElement("tr");
        row.dataset.id = leave.id;
        row.innerHTML = `
            <td>${leave.employeeName}</td>
            <td>${leave.leaveType}</td>
            <td>${start.toLocaleDateString()}</td>
            <td>${end.toLocaleDateString()}</td>
            <td>${totalDays}</td>
            <td><span class="status-badge ${leave.status.toLowerCase()}">${leave.status}</span></td>
            <td>${submitted.toLocaleDateString()}</td>
            <td>
                <button class="btn btn-sm btn-warning me-1 edit-btn">Edit</button>
                <button class="btn btn-sm btn-danger me-1 delete-btn">Delete</button>
                <button class="btn btn-sm btn-success me-1 approve-btn">Approve</button>
                <button class="btn btn-sm btn-secondary reject-btn">Reject</button>
            </td>
        `;
        table.appendChild(row);
    });
}

function updateDashboard(data) {
    const pending = data.filter(l => l.status === "Pending").length;
    const approved = data.filter(l => l.status === "Approved").length;
    const rejected = data.filter(l => l.status === "Rejected").length;
    const total = data.length;
    const percent = count => total ? Math.round((count / total) * 100) : 0;

    document.getElementById("pendingCount").innerText = pending;
    document.getElementById("approvedCount").innerText = approved;
    document.getElementById("rejectedCount").innerText = rejected;

    document.getElementById("pendingBar").style.width = percent(pending) + "%";
    document.getElementById("approvedBar").style.width = percent(approved) + "%";
    document.getElementById("rejectedBar").style.width = percent(rejected) + "%";
}

function filterLeaves() {
    const search = document.getElementById("searchInput").value.toLowerCase();
    const status = document.getElementById("statusFilter").value;

    const filtered = allLeaves.filter(l =>
        l.employeeName.toLowerCase().includes(search) &&
        (status === "" || l.status === status)
    );

    renderTable(filtered);
    updateDashboard(filtered);
}

// ----------------- EDIT -----------------
function openEditModal(id) {
    const leave = allLeaves.find(l => l.id == id);
    if (!leave) return;

    document.getElementById("editLeaveId").value = leave.id;
    document.getElementById("editEmployeeName").value = leave.employeeName;
    document.getElementById("editLeaveType").value = leave.leaveType;
    document.getElementById("editStartDate").value = leave.startDate.split("T")[0];
    document.getElementById("editEndDate").value = leave.endDate.split("T")[0];
    document.getElementById("editStatus").value = leave.status;
    document.getElementById("editSubmittedOn").value = leave.submittedOn.split("T")[0];

    new bootstrap.Modal(document.getElementById("editLeaveModal")).show();
}

async function saveEditLeave() {
    const id = document.getElementById("editLeaveId").value;
    const startDate = document.getElementById("editStartDate").value;
    const endDate = document.getElementById("editEndDate").value;

    if (new Date(startDate) > new Date(endDate)) {
        alert("Start Date cannot be after End Date!");
        return;
    }

    const updatedLeave = {
        employeeName: document.getElementById("editEmployeeName").value,
        leaveType: document.getElementById("editLeaveType").value,
        startDate,
        endDate,
        status: document.getElementById("editStatus").value,
        submittedOn: document.getElementById("editSubmittedOn").value
    };

    try {
        await fetch(`https://localhost:7272/api/Leave/UpdateLeave/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(updatedLeave)
        });

        bootstrap.Modal.getInstance(document.getElementById("editLeaveModal")).hide();
        loadLeaves();
    } catch (err) {
        alert("Failed to update leave!");
        console.error(err);
    }
}

// ----------------- DELETE -----------------
async function deleteLeave(id) {
    if (!confirm("Are you sure?")) return;
    try {
        await fetch(`https://localhost:7272/api/Leave/DeleteLeave/${id}`, { method: "DELETE" });
        loadLeaves();
    } catch (err) {
        alert("Delete failed!");
    }
}

// ----------------- STATUS -----------------
async function updateStatus(id, status) {
    try {
        await fetch(`https://localhost:7272/api/Leave/UpdateLeaveStatus/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(status)
        });
        loadLeaves();
    } catch {
        alert("Failed!");
    }
}

// ----------------- EXPORT -----------------
function exportCSV() {
    let csv = "Employee,Leave Type,Start,End,Total Days,Status,Submitted\n";
    allLeaves.forEach(l => {
        const start = new Date(l.startDate).toLocaleDateString();
        const end = new Date(l.endDate).toLocaleDateString();
        const submitted = new Date(l.submittedOn).toLocaleDateString();
        const totalDays = Math.round((new Date(l.endDate) - new Date(l.startDate)) / (1000 * 60 * 60 * 24)) + 1;

        csv += `"${l.employeeName}","${l.leaveType}","${start}","${end}","${totalDays}","${l.status}","${submitted}"\n`;
    });

    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "leave_dashboard.csv";
    a.click();
    URL.revokeObjectURL(url);
}