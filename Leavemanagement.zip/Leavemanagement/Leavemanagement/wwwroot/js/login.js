﻿// -----------------------------
// login.js
// -----------------------------

let users = [];
const loginBtn = document.getElementById("loginBtn");
const errorDiv = document.getElementById("error");
const loadingDiv = document.getElementById("loading");

// Disable login until users are loaded
loginBtn.disabled = true;
loadingDiv.innerText = "Loading user data...";

// LOAD USERS WHEN PAGE LOADS
window.onload = async function () {
    try {
        const response = await fetch("https://localhost:7272/api/Leave/GetUserDetails");
        if (!response.ok) throw new Error("Failed to fetch user data");

        users = await response.json();
        console.log("Users Loaded:", users);

        // Enable login button
        loginBtn.disabled = false;
        loadingDiv.innerText = ""; // hide loading message
    } catch (error) {
        console.error("API Load Error:", error);
        loadingDiv.innerText = "Failed to load users. Please try again later.";
    }
};

// LOGIN FUNCTION
function loginUser() {
    errorDiv.innerText = ""; // reset previous error

    if (users.length === 0) {
        errorDiv.innerText = "User data still loading...";
        return;
    }

    let username = document.getElementById("username").value.trim();
    let password = document.getElementById("password").value.trim();

    if (!username || !password) {
        errorDiv.innerText = "Please enter both username and password";
        return;
    }

    let user = users.find(u =>
        u.u_Name.trim().toLowerCase() === username.toLowerCase() &&
        u.u_Password.trim() === password
    );

    if (user) {
        console.log("User Found:", user);

        if (user.u_Type === "E") window.location.href = "/Leave/Create";
        else if (user.u_Type === "M") window.location.href = "/Leave/Index";
        else errorDiv.innerText = "Unknown user type.";
    } else {
        errorDiv.innerText = "Invalid Username or Password";
    }
}