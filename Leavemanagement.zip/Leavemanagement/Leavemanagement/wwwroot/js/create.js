﻿document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('leaveForm');
    const formAlert = document.getElementById('formAlert');
    const submitBtn = form.querySelector('button[type="submit"]');

    const employeeInput = document.getElementById('EmployeeName');
    const leaveTypeInput = document.getElementById('LeaveType');
    const startDateInput = document.getElementById('StartDate');
    const endDateInput = document.getElementById('EndDate');

    // ===== LIVE DATE VALIDATION =====
    const validateDates = () => {
        if (startDateInput.value && endDateInput.value) {
            if (new Date(endDateInput.value) < new Date(startDateInput.value)) {
                formAlert.innerHTML = `<div class="alert alert-danger rounded-3">
                    End Date cannot be before Start Date.
                </div>`;
                submitBtn.disabled = true;
            } else {
                formAlert.innerHTML = '';
                submitBtn.disabled = false;
            }
        } else {
            submitBtn.disabled = false; // allow submission if dates not yet selected
        }
    };

    startDateInput.addEventListener('change', () => {
        endDateInput.min = startDateInput.value;
        validateDates();
    });
    endDateInput.addEventListener('change', validateDates);

    // ===== FORM SUBMIT =====
    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        // ===== CHECK REQUIRED FIELDS ON SUBMIT =====
        const employeeName = employeeInput.value.trim();
        const leaveType = leaveTypeInput.value;
        const startDate = startDateInput.value;
        const endDate = endDateInput.value;

        if (!employeeName) {
            formAlert.innerHTML = `<div class="alert alert-danger rounded-3">
                Employee Name is required.
            </div>`;
            return;
        }

        if (!leaveType) {
            formAlert.innerHTML = `<div class="alert alert-danger rounded-3">
                Please select a Leave Type.
            </div>`;
            return;
        }

        if (!startDate || !endDate) {
            formAlert.innerHTML = `<div class="alert alert-danger rounded-3">
                Please select both Start and End dates.
            </div>`;
            return;
        }

        if (new Date(endDate) < new Date(startDate)) {
            formAlert.innerHTML = `<div class="alert alert-danger rounded-3">
                End Date cannot be before Start Date.
            </div>`;
            return;
        }

        // ===== SUBMIT PAYLOAD =====
        const payload = {
            id: 0,
            employeeName,
            leaveType,
            startDate,
            endDate,
            status: 'Pending',
            submittedOn: new Date().toISOString()
        };

        try {
            const response = await fetch('https://localhost:7272/api/Leave/AddLeave', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (response.ok) {
                const result = await response.json();
                formAlert.innerHTML = `<div class="alert alert-success rounded-3">
                    Leave request submitted successfully! (ID: ${result.id})
                </div>`;
                form.reset();
                endDateInput.min = '';
            } else {
                const errorResult = await response.json().catch(() => ({}));
                formAlert.innerHTML = `<div class="alert alert-danger rounded-3">
                    Error: ${errorResult.message || 'Could not submit leave.'}
                </div>`;
            }
        } catch (error) {
            formAlert.innerHTML = `<div class="alert alert-danger rounded-3">
                Error: ${error.message}
            </div>`;
        }
    });
});