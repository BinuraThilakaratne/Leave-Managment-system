﻿using System.ComponentModel.DataAnnotations;
using System;

namespace Leavemanagement.Models
{
    public class LeaveRequest
    {

       

      

        //// Primary Key
        public int Id { get; set; }


        //// Employee name
        [Required]
        public required string EmployeeName { get; set; }

        // Type of leave
        [Required]
        public required string LeaveType { get; set; }

        // Leave start date
        [Required]
        [DataType(DataType.Date)]
        public DateTime StartDate { get; set; }

        // Leave end date
        [Required]
        [DataType(DataType.Date)]
        public DateTime EndDate { get; set; }


        // Total number of leave days
        public int TotalDays { get; set; }

        // Leave status
        public string Status { get; set; } = "Pending";

        // Date when request was submitted
        public DateTime SubmittedOn { get; set; } = DateTime.Now;

        // Manager remarks
        public string? Remarks { get; set; }
    }
}

