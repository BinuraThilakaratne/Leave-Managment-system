﻿using ClosedXML.Excel; // Install ClosedXML via NuGet
using DocumentFormat.OpenXml.InkML;
using Leavemanagement.Models;
using Microsoft.AspNetCore.Mvc;


namespace Leavemanagement.Controllers
{
    public class LeaveController : Controller
    {
        //public IActionResult Index()
        //{
        //    return View();
        //}

        // Temporary in-memory data store
        private static List<LeaveRequest> leaveRequests = new List<LeaveRequest>
        {
            new LeaveRequest
            {
                Id = 1,
                EmployeeName = "John Doe",
                LeaveType = "Annual",
                StartDate = DateTime.Today,
                EndDate = DateTime.Today.AddDays(3),
                TotalDays = 3,
                Status = "Pending",
                SubmittedOn = DateTime.Today
            }
        };

        // GET: /Leave
        public IActionResult Index()
        {
            return View(leaveRequests);
        }

        // GET: /Leave/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: /Leave/Create
        [HttpPost]
        public IActionResult Create(LeaveRequest leave)
        {
            leave.Id = leaveRequests.Count > 0 ? leaveRequests.Max(l => l.Id) + 1 : 1;
            leave.SubmittedOn = DateTime.Today;
            leave.Status = "Pending";
            leave.TotalDays = (leave.EndDate - leave.StartDate).Days + 1;

            leaveRequests.Add(leave);
            return RedirectToAction("Index");
        }

        // GET: /Leave/Edit/{id}
        public IActionResult Edit(int id)
        {
            var leave = leaveRequests.FirstOrDefault(l => l.Id == id);
            if (leave == null) return NotFound();

            return View(leave);
        }
        

        // POST: /Leave/Edit/{id}
        [HttpPost]
        public IActionResult Edit(LeaveRequest updatedLeave)
        {
            var leave = leaveRequests.FirstOrDefault(l => l.Id == updatedLeave.Id);
            if (leave == null) return NotFound();

            leave.EmployeeName = updatedLeave.EmployeeName;
            leave.LeaveType = updatedLeave.LeaveType;
            leave.StartDate = updatedLeave.StartDate;
            leave.EndDate = updatedLeave.EndDate;
            leave.TotalDays = (updatedLeave.EndDate - updatedLeave.StartDate).Days + 1;

            return RedirectToAction("Index");
        }

        // POST: /Leave/Delete
        [HttpPost]
        public IActionResult Delete(int id)
        {
            var leave = leaveRequests.FirstOrDefault(l => l.Id == id);
            if (leave != null)
            {
                leaveRequests.Remove(leave);
            }
            return RedirectToAction("Index");
        }

        // GET: /Leave/Approve/{id}
        public IActionResult Approve(int id)
        {
            var leave = leaveRequests.FirstOrDefault(l => l.Id == id);
            if (leave != null) leave.Status = "Approved";

            return RedirectToAction("Index");
        }

        // GET: /Leave/Reject/{id}
        public IActionResult Reject(int id)
        {
            var leave = leaveRequests.FirstOrDefault(l => l.Id == id);
            if (leave != null) leave.Status = "Rejected";

            return RedirectToAction("Index");
        }


        public IActionResult ExportToExcel(string search = "", string status = "")
        {
            // Start with all leaves
            var leaves = leaveRequests.AsQueryable();

            // Apply search filter (employee name)
            if (!string.IsNullOrEmpty(search))
            {
                leaves = leaves.Where(l => l.EmployeeName.Contains(search, StringComparison.OrdinalIgnoreCase));
            }

            // Apply status filter
            if (!string.IsNullOrEmpty(status))
            {
                leaves = leaves.Where(l => l.Status.Equals(status, StringComparison.OrdinalIgnoreCase));
            }

            var leaveList = leaves.ToList();

            using (var workbook = new XLWorkbook())
            {
                var worksheet = workbook.Worksheets.Add("Leave Requests");

                // Add headers
                worksheet.Cell(1, 1).Value = "Employee";
                worksheet.Cell(1, 2).Value = "Leave Type";
                worksheet.Cell(1, 3).Value = "Start Date";
                worksheet.Cell(1, 4).Value = "End Date";
                worksheet.Cell(1, 5).Value = "Total Days";
                worksheet.Cell(1, 6).Value = "Status";
                worksheet.Cell(1, 7).Value = "Submitted On";

                // Fill data
                for (int i = 0; i < leaveList.Count; i++)
                {
                    var leave = leaveList[i];
                    worksheet.Cell(i + 2, 1).Value = leave.EmployeeName;
                    worksheet.Cell(i + 2, 2).Value = leave.LeaveType;
                    worksheet.Cell(i + 2, 3).Value = leave.StartDate.ToShortDateString();
                    worksheet.Cell(i + 2, 4).Value = leave.EndDate.ToShortDateString();
                    worksheet.Cell(i + 2, 5).Value = leave.TotalDays;
                    worksheet.Cell(i + 2, 6).Value = leave.Status;
                    worksheet.Cell(i + 2, 7).Value = leave.SubmittedOn.ToShortDateString();
                }

                using (var stream = new MemoryStream())
                {
                    workbook.SaveAs(stream);
                    var content = stream.ToArray();
                    return File(content,
                                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                "LeaveRequests.xlsx");
                }
            }
        }

    }
}
