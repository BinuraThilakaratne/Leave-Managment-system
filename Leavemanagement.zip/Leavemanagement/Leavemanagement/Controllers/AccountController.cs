﻿using Microsoft.AspNetCore.Mvc;

namespace Leavemanagement.Controllers
{
    public class AccountController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }
    }
}
