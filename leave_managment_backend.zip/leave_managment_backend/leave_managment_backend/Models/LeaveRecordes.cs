﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace leave_managment_backend.Models
{
    public class LeaveRecordes
    {
        [Key]
        public int Id { get; set; }  // Primary key

        [Required]
        [StringLength(100)]
        public string EmployeeName { get; set; }  // Employee Name

        [Required]
        [StringLength(20)]
        public string LeaveType { get; set; }  // "Annual", "Casual", "Sick"

        [Required]
        public DateTime StartDate { get; set; }  // Leave start date

        [Required]
        public DateTime EndDate { get; set; }  // Leave end date

        [NotMapped]  // Optional: calculated field, not stored in DB
        public int TotalDays
        {
            get
            {
                return (EndDate - StartDate).Days + 1; // Include both start & end
            }
        }

        [StringLength(20)]
        public string Status { get; set; } = "Pending";  // Default: Pending

        [Required]
        public DateTime SubmittedOn { get; set; } = DateTime.Now;  // Auto-set when request is created
    
    }
}
