﻿using System.ComponentModel.DataAnnotations;

namespace leave_managment_backend.Models
{
    public class Users
    {
        [Key]
        public int U_Id { get; set; }

        public string U_Name { get; set; }

        public string U_Password { get; set; }
        public string U_Type { get; set; }
    }
}
