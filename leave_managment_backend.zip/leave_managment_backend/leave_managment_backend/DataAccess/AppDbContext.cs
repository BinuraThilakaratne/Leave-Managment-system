﻿using leave_managment_backend.Models;
using Microsoft.EntityFrameworkCore;

namespace MyApiProject.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        public DbSet<Users> Users { get; set; }
        public DbSet<LeaveRecordes> LeaveRecords { get; set; }
    }
}