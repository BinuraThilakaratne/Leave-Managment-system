﻿using leave_managment_backend.Models;
using Microsoft.AspNetCore.Mvc;
using MyApiProject.Data;

namespace leave_managment_backend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LeaveController : ControllerBase
    {
        private readonly AppDbContext _context;

        public LeaveController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet("GetUserDetails")]
        public IActionResult GetUserdetails()
        {
            return Ok(_context.Users.ToList());
        }

        [HttpPost("PostUserDetails")]
        public IActionResult AddUser([FromBody] Users user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();

            return Ok(user);
        }


        //leaverecorde

        [HttpGet("GetAllLeaves")]
        public IActionResult GetAllLeaves()
        {
            var leaves = _context.LeaveRecords.ToList();
            return Ok(leaves);
        }

        // Get a leave request by Id
        [HttpGet("{id}")]
        public IActionResult GetLeaveById(int id)
        {
            var leave = _context.LeaveRecords.Find(id);
            if (leave == null) return NotFound();
            return Ok(leave);
        }

        // Add a new leave request
        [HttpPost("AddLeave")]
        public IActionResult AddLeave([FromBody] LeaveRecordes leave)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            _context.LeaveRecords.Add(leave);
            _context.SaveChanges();

            return Ok(leave);
        }
        //delete
        [HttpDelete("DeleteLeave/{id}")]
        public IActionResult DeleteLeave(int id)
        {
            var leave = _context.LeaveRecords.Find(id);

            if (leave == null)
                return NotFound();

            _context.LeaveRecords.Remove(leave);
            _context.SaveChanges();

            return Ok(new { message = "Leave deleted successfully" });
        }

        // Optional: update leave status
        [HttpPut("UpdateLeaveStatus/{id}")]
        public IActionResult UpdateLeaveStatus(int id, [FromBody] string status)
        {
            var leave = _context.LeaveRecords.Find(id);
            if (leave == null) return NotFound();

            leave.Status = status;
            _context.SaveChanges();

            return Ok(leave);
        }

        // PUT: api/Leave/UpdateLeave/{id}
        [HttpPut("UpdateLeave/{id}")]
        public IActionResult UpdateLeave(int id, [FromBody] LeaveRecordes updatedLeave)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var leave = _context.LeaveRecords.Find(id);
            if (leave == null) return NotFound();

            // Update all fields except Id
            leave.EmployeeName = updatedLeave.EmployeeName;
            leave.LeaveType = updatedLeave.LeaveType;
            leave.StartDate = updatedLeave.StartDate;
            leave.EndDate = updatedLeave.EndDate;
            leave.Status = updatedLeave.Status;
            leave.SubmittedOn = updatedLeave.SubmittedOn;

            _context.SaveChanges();

            return Ok(leave);
        }
    }
}